import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const PaginaPrincipal = ({ navigation }) => {
    const irParaLista = () => {
        navigation.navigate('ListarJogador'); 
    };

    return (
        <View style={styles.container}>
            <Text style={styles.header}>Essa é a Página Principal</Text>
            <Text style={styles.welcomeMessage}>Seja muito bem vindo(a)</Text>
            <TouchableOpacity style={styles.button} onPress={irParaLista}>
                <Text style={styles.buttonText}>Ir para Lista</Text> 
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#cbe8ff', 
        padding: 20,
    },
    header: {
        fontSize: 32, 
        fontWeight: 'bold',
        color: '#fff', 
        marginBottom: 20,
        textShadowColor: '#000', 
        textShadowOffset: { width: 2, height: 2 },
        textShadowRadius: 5,
    },
    welcomeMessage: {
        fontSize: 20, 
        color: '#fff', 
        marginBottom: 40,
        textAlign: 'center',
        paddingHorizontal: 10, 
        lineHeight: 26, 
    },
    button: {
        backgroundColor: '#6e96b5', 
        paddingVertical: 15,
        paddingHorizontal: 30,
        borderRadius: 25, 
        shadowColor: '#000', 
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.8,
        shadowRadius: 5,
        elevation: 5, 
    },
    buttonText: {
        fontSize: 18,
        color: '#fff',
        fontWeight: 'bold',
    },
});

export default PaginaPrincipal;