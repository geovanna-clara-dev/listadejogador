import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { getFirestore, collection, onSnapshot } from "firebase/firestore";
import app from '../config';

const ListarJogador = ({ navigation }) => {
    const [jogadores, setJogadores] = useState([]);

    useEffect(() => {
        const db = getFirestore(app);
        const jogadoresCollection = collection(db, 'real-madrid');

        const unsubscribe = onSnapshot(jogadoresCollection, querySnapshot => {
            const jogadoresList = querySnapshot.docs.map(doc => {
                const data = doc.data();
                return {
                    id: doc.id,
                    nome: data.nome || 'N/A', 
                    posicao: data.posicao || 'N/A', 
                    camisa: data.camisa || 'N/A', 
                    nascimento: formatDate(data.nascimento) || 'N/A',
                    altura: formatNumber(data.altura) || 'N/A'
                };
            });
            setJogadores(jogadoresList);
        });

        return () => unsubscribe();
    }, []);

    const formatDate = (timestamp) => {
        if (timestamp && timestamp.seconds) {
            const date = new Date(timestamp.seconds * 1000);
            return date.toLocaleDateString();
        }
        return 'N/A';
    };

    const formatNumber = (value) => {
        return typeof value === 'number' ? value.toString() : 'N/A';
    };

    const renderItem = ({ item }) => (
        <View style={styles.item}>
            <Text style={styles.name}>{item.nome}</Text>
            <Text style={styles.position}>{item.posicao}</Text>
            <Text style={styles.info}>Camisa: {item.camisa}</Text>
            <Text style={styles.info}>Nascimento: {item.nascimento}</Text>
            <Text style={styles.info}>Altura: {item.altura} cm</Text>
        </View>
    );

    return (
            <View style={styles.container}>
                <Text style={styles.header}>Lista de Jogadores</Text>
                <Text style={styles.welcomeMessage}>
                    Confira a lista completa dos jogadores do Real Madrid!
                </Text>
                <FlatList
                    data={jogadores}
                    renderItem={renderItem}
                    keyExtractor={item => item.id}
                />
                <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('OutraTela')}>
                    <Text style={styles.buttonText}>Ir para Outra Tela</Text>
                </TouchableOpacity>
            </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
    },
    header: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#6e96b5',
        marginBottom: 20,
        textAlign: 'center',
        textShadowColor: '#000',
        textShadowOffset: { width: 2, height: 2 },
        textShadowRadius: 5,
    },
    welcomeMessage: {
        fontSize: 20,
        color: '#ffffff',
        marginBottom: 40,
        textAlign: 'center',
        paddingHorizontal: 10,
        lineHeight: 26,
    },
    item: {
        backgroundColor: '#ffffff',
        padding: 15,
        marginVertical: 8,
        borderRadius: 10,
        shadowColor: '#000000',
        shadowOffset: { width: 1, height: 1 },
        shadowOpacity: 0.3,
        shadowRadius: 3,
        elevation: 3,
    },
    name: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#003366',
    },
    position: {
        fontSize: 16,
        color: '#666666',
    },
    info: {
        fontSize: 14,
        color: '#333333',
    },
    button: {
        backgroundColor: '#6e96b5',
        paddingVertical: 15,
        paddingHorizontal: 30,
        borderRadius: 25,
        shadowColor: '#000',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.8,
        shadowRadius: 5,
        elevation: 5,
        marginTop: 20,
    },
    buttonText: {
        fontSize: 18,
        color: '#fff',
        fontWeight: 'bold',
    },
});

export default ListarJogador;
