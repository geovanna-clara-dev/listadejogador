
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAY24Ip0iM9UmtAgEIEqW-dGMdljqSr2Kg",
  authDomain: "auth-firebase-geovanna-aula1.firebaseapp.com",
  projectId: "auth-firebase-geovanna-aula1",
  storageBucket: "auth-firebase-geovanna-aula1.appspot.com",
  messagingSenderId: "755753746878",
  appId: "1:755753746878:web:0d40d18aa920f2eac379ef",
  measurementId: "G-SE2DM7D3R1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export default app;